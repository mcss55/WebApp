package com.mcss.webapp.classForTest;

import java.util.ArrayList;

public class database {
    public static ArrayList<Person> arr=new ArrayList<>();
}
