package com.mcss.webapp;

import com.mcss.webapp.classForTest.Person;

import java.util.Date;

public class Hekimler {
    private int id;
    private String ad;
    private String soyad;
    private String mail;
    private String hekimlik_sahesi;
    private String hire_date;

    public String getAd() {
        return ad;
    }

    public void setAd(String ad) {
        this.ad = ad;
    }

    public String getSoyad() {
        return soyad;
    }

    public void setSoyad(String soyad) {
        this.soyad = soyad;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getHekimlik_sahesi() {
        return hekimlik_sahesi;
    }

    public void setHekimlik_sahesi(String hekimlik_sahesi) {
        this.hekimlik_sahesi = hekimlik_sahesi;
    }

    public String getHire_date() {
        return hire_date;
    }

    public void setHire_date(String hire_date) {
        this.hire_date = hire_date;
    }

    public Hekimler(String ad, String soyad, String mail, String hekimlik_sahesi) {
        this.ad = ad;
        this.soyad = soyad;
        this.mail = mail;
        this.hekimlik_sahesi = hekimlik_sahesi;
        this.hire_date = Person.convertToDate(new Date().toString());
    }
}
