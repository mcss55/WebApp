package com.mcss.webapp;

import com.mcss.webapp.classForTest.Person;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;


public class DataConnect {


    static Connection connection = null;
    static PreparedStatement PrepareStat = null;

    public DataConnect() {
    }

    public static void makeJDBCConnection() {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            return;
        }

        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/web_app", "root", "");
            if (connection != null) {
            } else {
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return;
        }

    }

    public static void addDataToDB(String username, String ad, String soyad, String dogum_tarixi, String mail, String sifre) {
        makeJDBCConnection();
        try {
            String insertQueryStatement = "INSERT  INTO  istifadeciler  VALUES  (?,?,?,?,?,?,?,?)";

            PrepareStat = connection.prepareStatement(insertQueryStatement);
            PrepareStat.setInt(1, 0);
            PrepareStat.setString(2, username);
            PrepareStat.setString(3, ad);
            PrepareStat.setString(4, soyad);
            PrepareStat.setString(5, dogum_tarixi);
            PrepareStat.setString(6, mail);
            PrepareStat.setString(7, sifre);
            PrepareStat.setString(8, Person.convertToDate(new Date().toString()));
            PrepareStat.executeUpdate();
        } catch (

                SQLException e) {
            e.printStackTrace();
        }
    }

    public static List<Istifadeci> getDataFromDB() {
        makeJDBCConnection();
        List<Istifadeci> arr=new ArrayList<Istifadeci>();
        try {
            String getQueryStatement = "SELECT * FROM istifadeciler";

            PrepareStat = connection.prepareStatement(getQueryStatement);

            ResultSet rs = PrepareStat.executeQuery();

            while (rs.next()) {
                Integer id = rs.getInt("ID");
                String username = rs.getString("USERNAME");
                String ad = rs.getString("AD");
                String soyad = rs.getString("SOYAD");
                String dogum_tarixi = rs.getString("DOGUM_TARIXI");
                String mail = rs.getString("MAIL");
                String sifre = rs.getString("SIFRE");
                String hire_date = rs.getString("HIRE_DATE");
                arr.add(new Istifadeci(id,username,ad,soyad,dogum_tarixi,mail,sifre));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return arr;

    }
    public static boolean checkIfHave(String username) {
        makeJDBCConnection();
        try {
            String getQueryStatement = String.format("SELECT * FROM istifadeciler WHERE USERNAME='%s'",username);

            PrepareStat = connection.prepareStatement(getQueryStatement);

            ResultSet rs = PrepareStat.executeQuery();
            String sifre=null;
            while (rs.next()) {
                sifre = rs.getString("USERNAME");
            }
            if (sifre == null) {
                return true;
            }else {
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    public static boolean checkLoginAuth(String username,String sifre) {
        makeJDBCConnection();
        try {
            String getQueryStatement = String.format("SELECT USERNAME,SIFRE FROM istifadeciler WHERE USERNAME='%s'",username);

            PrepareStat = connection.prepareStatement(getQueryStatement);

            ResultSet rs = PrepareStat.executeQuery();
            String usernameDb=null;
            String sifreDb=null;
            while (rs.next()) {
                usernameDb = rs.getString("USERNAME");
                sifreDb = rs.getString("SIFRE");
            }
            if (usernameDb == null || sifreDb == null) {
                return false;
            }else {
                if (usernameDb.equals(username) && sifreDb.equals(sifre)) {
                    return true;
                }else {
                    return false;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    public static void deleteData(String ad, String soyad, String username, String dogum_tarixi, String mail, String hire_date) throws SQLException {
        makeJDBCConnection();
        String getQueryStatement = String.format("DELETE FROM istifadeciler WHERE  AD='%s' AND SOYAD='%s' AND USERNAME='%s' AND DOGUM_TARIXI='%s' AND MAIL='%s' AND HIRE_DATE='%s'"
                ,ad,soyad,username,dogum_tarixi,mail,hire_date);
        PrepareStat = connection.prepareStatement(getQueryStatement);
        PrepareStat.executeUpdate();
    }
    public static void updateData(int id,String updatedName, String updatedSurname) throws SQLException {
        makeJDBCConnection();
        String getQueryStatement = String.format("UPDATE istifadeciler SET AD='%s',SOYAD='%s' WHERE ID='%s'",updatedName,updatedSurname,id);
        PrepareStat = connection.prepareStatement(getQueryStatement);
        PrepareStat.executeUpdate();
    }
    public static List<Hekimler> getHekimlerFromDb(){
        makeJDBCConnection();
        List<Hekimler> arr=new ArrayList<>();
        try {
            String getQueryStatement = "SELECT * FROM hekimler";

            PrepareStat = connection.prepareStatement(getQueryStatement);

            ResultSet rs = PrepareStat.executeQuery();

            while (rs.next()) {
                String ad = rs.getString("AD");
                String soyad = rs.getString("SOYAD");
                String mail = rs.getString("MAIL");
                String hekimlik_sahesi = rs.getString("HEKIMLIK_SAHESI");
                arr.add(new Hekimler(ad,soyad,mail,hekimlik_sahesi));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return arr;
    }
    public static void addHekimDataToDB(String ad, String soyad, String hekimlik_sahesi, String mail, String hire_date) {
        makeJDBCConnection();
        try {
            String insertQueryStatement = "INSERT  INTO  hekimler  VALUES  (?,?,?,?,?,?)";

            PrepareStat = connection.prepareStatement(insertQueryStatement);
            PrepareStat.setInt(1, 0);
            PrepareStat.setString(2, ad);
            PrepareStat.setString(3, soyad);
            PrepareStat.setString(4, mail);
            PrepareStat.setString(5, hekimlik_sahesi);
            PrepareStat.setString(6, hire_date);
            PrepareStat.executeUpdate();
        } catch (

                SQLException e) {
            e.printStackTrace();
        }
    }
    public static void deleteHekimData(String ad, String soyad, String mail, String hire_date, String hekimlik_sahesi) throws SQLException {
        makeJDBCConnection();
        String getQueryStatement = String.format("DELETE FROM `hekimler` WHERE AD='%s' AND SOYAD='%s' AND MAIL='%s' AND HEKIMLIK_SAHESI='%s' AND HIRE_DATE='%s';"
                ,ad, soyad, mail,hekimlik_sahesi, hire_date);
        PrepareStat = connection.prepareStatement(getQueryStatement);
        PrepareStat.executeUpdate();
    }
    public static void inserToAdminAndDeleteFromUser(String username) throws SQLException {
        makeJDBCConnection();
        String query=String.format("insert into admin (select * from istifadeciler where username='%s')",username);
        String query2=String.format("delete from istifadeciler where username='%s'",username);
        PrepareStat=connection.prepareStatement(query);
        PrepareStat.executeUpdate();
        PrepareStat=connection.prepareStatement(query2);
        PrepareStat.executeUpdate();
    }
    public static void inserToBlockedUserAndDeleteFromUser(String username) throws SQLException {
        makeJDBCConnection();
        String query=String.format("insert into bloklanmis_userler (select * from istifadeciler where username='%s')",username);
        String query2=String.format("delete from istifadeciler where username='%s'",username);
        PrepareStat=connection.prepareStatement(query);
        PrepareStat.executeUpdate();
        PrepareStat=connection.prepareStatement(query2);
        PrepareStat.executeUpdate();
    }
    //SELECT COUNT(*) FROM `bloklanmis_userler` WHERE USERNAME='ibrahim'
    public static boolean checkIfHaveInBlockedUser(String username) throws SQLException {
        makeJDBCConnection();
        String booleanDb="";
        String query=String
                .format("select USERNAME, CASE when USERNAME='%s' then 'true' else 'false' END as boolean from bloklanmis_userler;"
                ,username);
        PrepareStat=connection.prepareStatement(query);
        ResultSet rs = PrepareStat.executeQuery();
        while (rs.next()) {
            booleanDb=rs.getString(2);
            System.out.println(username);
        }
        if (booleanDb.equals("true"))
            return true;
        else
            return false;
    }
    public static boolean checkAdminLogin(String username,String sifre) {
        makeJDBCConnection();
        try {
            String getQueryStatement = String.format("SELECT USERNAME,SIFRE FROM admin WHERE USERNAME='%s'",username);

            PrepareStat = connection.prepareStatement(getQueryStatement);

            ResultSet rs = PrepareStat.executeQuery();
            String usernameDb=null;
            String sifreDb=null;
            while (rs.next()) {
                usernameDb = rs.getString("USERNAME");
                sifreDb = rs.getString("SIFRE");
            }
            if (usernameDb == null || sifreDb == null) {
                return false;
            }else {
                if (usernameDb.equals(username) && sifreDb.equals(sifre)) {
                    return true;
                }else {
                    return false;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}