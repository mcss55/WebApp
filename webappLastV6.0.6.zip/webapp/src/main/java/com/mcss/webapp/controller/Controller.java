package com.mcss.webapp.controller;
import com.mcss.webapp.DataConnect;
import com.mcss.webapp.Hekimler;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import java.sql.*;
import java.util.*;
import java.util.Date;

@org.springframework.stereotype.Controller
public class Controller extends DataConnect{
    public String toUpper(String str){
        return str.replace(str.charAt(0),Character.toUpperCase(str.charAt(0)));
    }
    @GetMapping("/")
    public String index(){
        return "index";
    }
    @GetMapping("/register")
    public String goToReg(){
        return "register";
    }
    @RequestMapping("/qeydiyyatSorgusu")
    public String qeydiyyatEt(@RequestParam String username, @RequestParam String adReg, @RequestParam String soyadReg, @RequestParam String dogum_tarixi, @RequestParam String mail, @RequestParam String sifre, @RequestParam String sifre_tekrar) throws SQLException {
        if(!username.isEmpty() && DataConnect.checkIfHave(username) && username.length()>3
        && Integer.valueOf(Arrays.asList(new Date().toString().split(" ")).get(5))-Integer.valueOf(Arrays.asList(dogum_tarixi.split("-")).get(0))>13
        && mail.contains("@") && sifre.equals(sifre_tekrar) && sifre.length()>7 && !checkIfHaveInBlockedUser(username)){
            addDataToDB(username,adReg,soyadReg,dogum_tarixi,mail,sifre);
        }
        return index();
    }
    @GetMapping("/usersDashboard")
    public String dashboard(){
        return "usersDashboard";
    }
    @RequestMapping("/loginReq")
    public ModelAndView login(Model model, @RequestParam String username, @RequestParam String sifre) throws SQLException {
        if (DataConnect.checkLoginAuth(username, sifre)) {
            model.addAttribute("errormsg","");
            RedirectView redirectView = new RedirectView("/usersDashboard");
            redirectView.setExposePathVariables(false);
            return new ModelAndView(redirectView);
        } else if (checkIfHaveInBlockedUser(username)) {
            model.addAttribute("errormsg","Bu istifadechi bloklanmishdir");
        } else if(DataConnect.checkAdminLogin(username, sifre)){
            RedirectView redirectView = new RedirectView("/adminPanel");
            redirectView.setExposePathVariables(false);
            return new ModelAndView(redirectView);
        }else{
            model.addAttribute("errormsg","Username ve ya shifre yalnishdir");
        }
        RedirectView redirectView = new RedirectView("/");
        redirectView.setExposePathVariables(false);
        return new ModelAndView(redirectView);
    }
    // Burda qalmishdiq
    @GetMapping("/hekimEmeliyyatlari")
    public String hekimEmeliyyats(Model model){
        model.addAttribute("Hekimler",DataConnect.getHekimlerFromDb());
        return "hekimEmeliyyati";
    }
    @RequestMapping("/elaveEt")
    public String hekimElaveEt(Model model, @RequestParam String ad, @RequestParam String soyad, @RequestParam String mail, @RequestParam String hire_date, @RequestParam String hekimlik_sahesi){
        DataConnect.addHekimDataToDB(ad,soyad,hekimlik_sahesi,mail,hire_date);
        return hekimEmeliyyats(model);
    }
    @RequestMapping("/sil")
    public String hekimSil(Model model, @RequestParam String ad, @RequestParam String soyad, @RequestParam String mail, @RequestParam String hire_date, @RequestParam String hekimlik_sahesi) throws SQLException {
        DataConnect.deleteHekimData(ad,soyad,mail,hire_date,hekimlik_sahesi);
        return hekimEmeliyyats(model);
    }
    @GetMapping("/adminPanel")
    public String adminPanel(){
        return "adminPanel";
    }
    @GetMapping("/istifadechiEmeliyyatlari")
    public String istifadeciEmeliyyats(Model model){
        model.addAttribute("istifadeci", DataConnect.getDataFromDB());
        return "istifadechiEmeliyyatlari";
    }
    @RequestMapping("/deleteIstifadechi")
    public String demo(Model model,@RequestParam String ad, @RequestParam String soyad, @RequestParam String username,
                       @RequestParam String dogum_tarixi, @RequestParam String mail, @RequestParam String hire_date) throws SQLException {
        DataConnect.deleteData(ad,soyad,username,dogum_tarixi,mail,hire_date);
        return istifadeciEmeliyyats(model);
    }
    @GetMapping("/adminEmeliyyatlari")
    public String adminEmeliyyats(Model model){
        model.addAttribute("istifadeci", DataConnect.getDataFromDB());
        return "adminEmeliyyatlari";
    }
    @RequestMapping("/adminEt")
    public String adminEt(Model model,@RequestParam String username) throws SQLException {
        DataConnect.inserToAdminAndDeleteFromUser(username);
        return adminEmeliyyats(model);
    }
    @RequestMapping("/blokEt")
    public String blokEt(Model model,@RequestParam String username) throws SQLException {
        DataConnect.inserToBlockedUserAndDeleteFromUser(username);
        return adminEmeliyyats(model);
    }
    // !!!!!! Admin panelinde hekim elave etmek ve hekim silmek kimi funksiyalar elave etmelisen
    // Daha sonra listdeki hekim adlarini alfabetik siraya gore tablede yazdirmaq !!!!! bunu elesem mene halaldi :)
    // Hekimler panelini yeni dizaynda(istifadeci dizayninda deyish)
    // 
}