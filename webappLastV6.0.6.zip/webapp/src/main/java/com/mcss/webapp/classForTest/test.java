package com.mcss.webapp.classForTest;

import com.mcss.webapp.DataConnect;

import javax.xml.crypto.Data;
import java.sql.SQLException;
import java.util.*;

public class test{

    public static void main(String[] args) {
        System.out.println(DataConnect.checkAdminLogin("admin","semral123"));
        System.out.println(DataConnect.checkAdminLogin("admin","semral1223"));
    }
}
