package com.mcss.webapp.controller;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import com.mcss.webapp.DataConnect;
import com.mcss.webapp.Ishciler;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.xml.ws.Service;
import java.sql.*;
@org.springframework.stereotype.Controller
public class Controller extends DataConnect{
    public String toUpper(String str){
        return str.replace(str.charAt(0),Character.toUpperCase(str.charAt(0)));
    }
    @GetMapping("/")
    public String index(){
        return "index";
    }
    @PostMapping(path = "/sendData")
    public String getNames(Model model, @RequestParam String ad, @RequestParam String soyad) throws ClassNotFoundException, SQLException {
        model.addAttribute("ad",toUpper(ad));
        model.addAttribute("soyad",toUpper(soyad));
        DataConnect.addDataToDB(toUpper(ad),toUpper(soyad));
        return "success";
    }
    @GetMapping("/getData")
    public String getDatas(Model model){
        model.addAttribute("adlar", DataConnect.getDataFromDB());
        return "getData";
    }
    @GetMapping("/deleteIshci")
    public String deleteishci() {
        return "delete";
    }
    @RequestMapping("/deletePer")
    public String deleteIshci(Model model,@RequestParam Integer deletedId) throws SQLException {
        DataConnect.deleteData(deletedId);
        return getDatas(model);
    }
    @GetMapping("/updateIshci")
    public String updateIndex(){
        return "updateIshci";
    }
    @RequestMapping("/updatePer")
    public String updateIshci(Model model,@RequestParam String ad,@RequestParam String soyad,@RequestParam int id) throws SQLException {
        DataConnect.updateData(id,ad,soyad);
        return getDatas(model);
    }
}