package com.mcss.webapp.controller;
import com.mcss.webapp.DataConnect;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.sql.*;
import java.util.*;
import java.util.Date;

@org.springframework.stereotype.Controller
public class Controller extends DataConnect{
    public String toUpper(String str){
        return str.replace(str.charAt(0),Character.toUpperCase(str.charAt(0)));
    }
    @GetMapping("/")
    public String index(){
        return "index";
    }
    @PostMapping(path = "/sendData")
    public String getNames(Model model, @RequestParam String ad, @RequestParam String soyad) throws ClassNotFoundException, SQLException {
        model.addAttribute("ad",toUpper(ad));
        model.addAttribute("soyad",toUpper(soyad));
        //DataConnect.addDataToDB(toUpper(ad),toUpper(soyad));
        return "success";
    }
    @GetMapping("/getData")
    public String getDatas(Model model){
        model.addAttribute("adlar", DataConnect.getDataFromDB());
        return "getData";
    }
    @GetMapping("/deleteIshci")
    public String deleteishci() {
        return "delete";
    }
    @RequestMapping("/deletePer")
    public String deleteIshci(Model model,@RequestParam Integer deletedId) throws SQLException {
        DataConnect.deleteData(deletedId);
        return getDatas(model);
    }
    @GetMapping("/updateIshci")
    public String updateIndex(){
        return "updateIshci";
    }
    @RequestMapping("/updatePer")
    public String updateIshci(Model model,@RequestParam String ad,@RequestParam String soyad,@RequestParam int id) throws SQLException {
        DataConnect.updateData(id,ad,soyad);
        return getDatas(model);
    }
    @GetMapping("/register")
    public String goToReg(){
        return "register";
    }
    @RequestMapping("/qeydiyyatSorgusu")
    public String qeydiyyatEt(Model model,@RequestParam String username, @RequestParam String adReg, @RequestParam String soyadReg, @RequestParam String dogum_tarixi, @RequestParam String mail, @RequestParam String sifre, @RequestParam String sifre_tekrar){
        if(!username.isEmpty() && DataConnect.checkIfHave(username) && username.length()>3
        && Integer.valueOf(Arrays.asList(new Date().toString().split(" ")).get(5))-Integer.valueOf(Arrays.asList(dogum_tarixi.split("-")).get(0))>13
        && mail.contains("@") && sifre.equals(sifre_tekrar) && sifre.length()>7
        ){
            addDataToDB(username,adReg,soyadReg,dogum_tarixi,mail,sifre);
        }
        return index();
    }
    @GetMapping("/usersDashboard")
    public String dashboard(){
        return "usersDashboard";
    }
    @RequestMapping("/loginReq")
    public String login(Model model, @RequestParam String username, @RequestParam String sifre){
        if (DataConnect.checkLoginAuth(username, sifre)) {
            model.addAttribute("errormsg","");
            return "usersDashboard";
        }else {
            model.addAttribute("errormsg","Username ve ya sifre yalnisdir");
        }
        return index();
    }
}