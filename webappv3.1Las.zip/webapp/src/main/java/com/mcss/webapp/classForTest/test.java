package com.mcss.webapp.classForTest;

import com.mcss.webapp.DataConnect;

import java.util.*;

public class test{
    void createPerson(){
        Scanner scanner=new Scanner(System.in);
        System.out.println("Ad:  ");
        String ad=scanner.nextLine();
        System.out.println("Soyad:  ");
        String soyad=scanner.nextLine();
        System.out.println("Yas:  ");
        String yas=scanner.nextLine();
        //database.arr.add(new Person(ad,soyad,yas));
        System.out.println(database.arr.get(0).getAd());
        System.out.println(database.arr.get(0).getSoyad());
        System.out.println(database.arr.get(0).getDogum_tarixi());
    }
    public static void main(String[] args) {
        System.out.println(
                DataConnect.checkLoginAuth("mcss","maqa64466"));
        /*
        System.out.println(person.getHireDate(0));
        System.out.println(person.getHireDate(1));
        System.out.println(person.getHireDate(2));
        System.out.println(person.getHireDate(3));
        System.out.println(person.getHireDate(4));
        */
    }
}
