package com.mcss.webapp;

import com.mcss.webapp.classForTest.Person;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;


public class DataConnect {


    static Connection connection = null;
    static PreparedStatement PrepareStat = null;

    public DataConnect() {
    }

    public static void makeJDBCConnection() {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            return;
        }

        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/web_app", "root", "");
            if (connection != null) {
            } else {
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return;
        }

    }

    public static void addDataToDB(String username, String ad, String soyad, String dogum_tarixi, String mail, String sifre) {
        makeJDBCConnection();
        try {
            String insertQueryStatement = "INSERT  INTO  ishciler  VALUES  (?,?,?,?,?,?,?,?)";

            PrepareStat = connection.prepareStatement(insertQueryStatement);
            PrepareStat.setInt(1, 0);
            PrepareStat.setString(2, username);
            PrepareStat.setString(3, ad);
            PrepareStat.setString(4, soyad);
            PrepareStat.setString(5, dogum_tarixi);
            PrepareStat.setString(6, mail);
            PrepareStat.setString(7, sifre);
            PrepareStat.setString(8, Person.convertToDate(new Date().toString()));
            PrepareStat.executeUpdate();
        } catch (

                SQLException e) {
            e.printStackTrace();
        }
    }

    public static List<Ishciler> getDataFromDB() {
        makeJDBCConnection();
        List<Ishciler> arr=new ArrayList<Ishciler>();
        try {
            String getQueryStatement = "SELECT * FROM ishciler";

            PrepareStat = connection.prepareStatement(getQueryStatement);

            ResultSet rs = PrepareStat.executeQuery();

            while (rs.next()) {
                Integer id = rs.getInt("ID");
                String username = rs.getString("USERNAME");
                String ad = rs.getString("AD");
                String soyad = rs.getString("SOYAD");
                String dogum_tarixi = rs.getString("DOGUM_TARIXI");
                String mail = rs.getString("MAIL");
                String sifre = rs.getString("SIFRE");
                String hire_date = rs.getString("HIRE_DATE");
                arr.add(new Ishciler(id,username,ad,soyad,dogum_tarixi,mail,sifre));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return arr;

    }
    public static boolean checkIfHave(String username) {
        makeJDBCConnection();
        try {
            String getQueryStatement = String.format("SELECT * FROM ishciler WHERE USERNAME='%s'",username);

            PrepareStat = connection.prepareStatement(getQueryStatement);

            ResultSet rs = PrepareStat.executeQuery();
            String sifre=null;
            while (rs.next()) {
                sifre = rs.getString("USERNAME");
            }
            if (sifre == null) {
                return true;
            }else {
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    public static boolean checkLoginAuth(String username,String sifre) {
        makeJDBCConnection();
        try {
            String getQueryStatement = String.format("SELECT USERNAME,SIFRE FROM ishciler WHERE USERNAME='%s'",username);

            PrepareStat = connection.prepareStatement(getQueryStatement);

            ResultSet rs = PrepareStat.executeQuery();
            String usernameDb=null;
            String sifreDb=null;
            while (rs.next()) {
                usernameDb = rs.getString("USERNAME");
                sifreDb = rs.getString("SIFRE");
            }
            if (usernameDb == null || sifreDb == null) {
                return false;
            }else {
                if (usernameDb.equals(username) && sifreDb.equals(sifre)) {
                    return true;
                }else {
                    return false;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    public static void deleteData(Integer deletedId) throws SQLException {
        makeJDBCConnection();
        String getQueryStatement = String.format("DELETE FROM ishciler WHERE ID=\"%s\"",deletedId);
        PrepareStat = connection.prepareStatement(getQueryStatement);
        PrepareStat.executeUpdate();
    }
    public static void updateData(int id,String updatedName, String updatedSurname) throws SQLException {
        makeJDBCConnection();
        String getQueryStatement = String.format("UPDATE ishciler SET AD='%s',SOYAD='%s' WHERE ID='%s'",updatedName,updatedSurname,id);
        PrepareStat = connection.prepareStatement(getQueryStatement);
        PrepareStat.executeUpdate();
    }
    /*
    update ishciler
set AD='Feride'
where AD='Ferid'
    */
}