package com.mcss.webapp;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

public class Ishciler implements Serializable {
    private Integer id;
    private String username;
    private String ad;
    private String soyad;
    private String dogum_tarixi;
    private String hire_date =null;
    private String mail;
    private String sifre;

    public String monthToInt(String month){
        switch(month){
            case "Jan":
                return "01";
            case "Feb":
                return "02";
            case "Mar":
                return "03";
            case "Apr":
                return "04";
            case "May":
                return "05";
            case "Jun":
                return "06";
            case "Jul":
                return "07";
            case "Aug":
                return "08";
            case "Sep":
                return "09";
            case "Oct":
                return "10";
            case "Nov":
                return "11";
            case "Dec":
                return "12";
            default:
                return "00";
        }
    }
    public String convertToDate(String date){
        ArrayList<String> arr=new ArrayList<>(Arrays.asList(date.split(" ")));
        String s="";
        s+=arr.get(2)+"."+monthToInt(arr.get(1))+"."+arr.get(5);
        return s;
    }


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getAd() {
        return ad;
    }

    public void setAd(String ad) {
        this.ad = ad;
    }

    public String getSoyad() {
        return soyad;
    }

    public void setSoyad(String soyad) {
        this.soyad = soyad;
    }

    public String getDogum_tarixi() {
        return dogum_tarixi;
    }

    public void setDogum_tarixi(String dogum_tarixi) {
        this.dogum_tarixi = dogum_tarixi;
    }

    public String getHire_date() {
        return hire_date;
    }

    public void setHire_date(String hire_date) {
        this.hire_date = hire_date;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getSifre() {
        return sifre;
    }

    public void setSifre(String sifre) {
        this.sifre = sifre;
    }

    public Ishciler(Integer id, String username, String ad, String soyad, String dogum_tarixi, String mail, String sifre) {
        this.id = id;
        this.username = username;
        this.ad = ad;
        this.soyad = soyad;
        this.dogum_tarixi = dogum_tarixi;
        this.hire_date = new Date().toString();
        this.mail = mail;
        this.sifre = sifre;
    }
}
