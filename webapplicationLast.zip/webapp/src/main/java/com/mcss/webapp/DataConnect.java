package com.mcss.webapp;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DataConnect {


    static Connection connection = null;
    static PreparedStatement PrepareStat = null;

    public DataConnect() {
    }

    public static void makeJDBCConnection() {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            return;
        }

        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/web_app", "root", "");
            if (connection != null) {
            } else {
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return;
        }

    }

    public static void addDataToDB(String ad, String soyad) {
        makeJDBCConnection();
        try {
            String insertQueryStatement = "INSERT  INTO  ishciler  VALUES  (?,?)";

            PrepareStat = connection.prepareStatement(insertQueryStatement);
            PrepareStat.setString(1, ad);
            PrepareStat.setString(2, soyad);
            PrepareStat.executeUpdate();
        } catch (

                SQLException e) {
            e.printStackTrace();
        }
    }

    public static List<Ishciler> getDataFromDB() {
        makeJDBCConnection();
        List<Ishciler> arr=new ArrayList<Ishciler>();
        try {
            String getQueryStatement = "SELECT * FROM ishciler";

            PrepareStat = connection.prepareStatement(getQueryStatement);

            ResultSet rs = PrepareStat.executeQuery();

            while (rs.next()) {
                String ad = rs.getString("AD");
                String soyad = rs.getString("SOYAD");
                arr.add(new Ishciler(ad,soyad));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return arr;

    }
    public static void deleteData(String ad) throws SQLException {
        makeJDBCConnection();
        String getQueryStatement = "DELETE FROM ishciler"+"WHERE AD="+ad;
        PrepareStat = connection.prepareStatement(getQueryStatement);
        PrepareStat.executeUpdate();
    }
}