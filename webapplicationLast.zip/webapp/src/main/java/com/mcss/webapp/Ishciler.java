package com.mcss.webapp;

import java.io.Serializable;

public class Ishciler implements Serializable {
    private String ad;
    private String soyad;

    public Ishciler(String ad,String soyad) {
        this.ad = ad;
        this.soyad = soyad;
    }

    public String getAd() {
        return ad;
    }

    public void setAd(String ad) {
        this.ad = ad;
    }

    public String getSoyad() {
        return soyad;
    }

    public void setSoyad(String soyad) {
        this.soyad = soyad;
    }
}
